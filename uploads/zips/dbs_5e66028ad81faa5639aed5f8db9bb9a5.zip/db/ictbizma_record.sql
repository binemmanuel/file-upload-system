-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jan 09, 2020 at 02:12 PM
-- Server version: 5.7.28
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ictbizma_record`
--

-- --------------------------------------------------------

--
-- Table structure for table `coupon_code`
--

CREATE TABLE `coupon_code` (
  `id` int(11) NOT NULL,
  `coupon_code` varchar(15) NOT NULL,
  `course` int(11) NOT NULL,
  `descount` int(100) NOT NULL,
  `start` datetime DEFAULT CURRENT_TIMESTAMP,
  `end` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `coupon_code`
--

INSERT INTO `coupon_code` (`id`, `coupon_code`, `course`, `descount`, `start`, `end`) VALUES
(1, 'bm55LK9AD6', 1, 30, '2019-12-13 14:54:05', '2020-01-13 14:54:05');

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `id` int(11) NOT NULL,
  `course` varchar(65) NOT NULL,
  `price` int(11) NOT NULL,
  `duration` int(11) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`id`, `course`, `price`, `duration`, `description`) VALUES
(1, 'Web Development', 100, 2, 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Facere nam accusantium, repudiandae atque ipsum molestias placeat sit, tempora tenetur quo laboriosam rem assumenda suscipit, excepturi est veritatis. Itaque, commodi quam! Lorem ipsum dolor sit ame'),
(4, 'Web Design', 220000, 7, 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Facere nam accusantium, repudiandae atque ipsum molestias placeat sit, tempora tenetur quo laboriosam rem assumenda suscipit, excepturi est veritatis. Itaque, commodi quam! Lorem ipsum dolor sit ame'),
(5, 'Graphic Design', 10000, 1, 'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Exercitationem amet id sunt quasi deleniti similique? Quidem, soluta recusandae! Labore aperiam nemo eaque consectetur! Exercitationem provident consequatur iusto impedit. Quod, cumque?'),
(6, 'Game Development', 50000, 3, 'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Exercitationem amet id sunt quasi deleniti similique? Quidem, soluta recusandae! Labore aperiam nemo eaque consectetur! Exercitationem provident consequatur iusto impedit. Quod, cumque?\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Exercitationem amet id sunt quasi deleniti similique? Quidem, soluta recusandae! Labore aperiam nemo eaque consectetur! Exercitationem provident consequatur iusto impedit. Quod, cumque?\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Exercitationem amet id sunt quasi deleniti similique? Quidem, soluta recusandae! Labore aperiam nemo eaque consectetur! Exercitationem provident consequatur iusto impedit. Quod, cumque?'),
(7, 'Adobe Packages', 40000, 10, 'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Exercitationem amet id sunt quasi deleniti similique? Quidem, soluta recusandae! Labore aperiam nemo eaque consectetur! Exercitationem provident consequatur iusto impedit. Quod, cumque? Lorem ipsum dolor sit amet consectetur, adipisicing elit. Exercitationem amet id sunt quasi deleniti similique? Quidem, soluta recusandae! Labore aperiam nemo eaque consectetur! Exercitationem provident consequatur iusto impedit. Quod, cumque? Lorem ipsum dolor sit amet consectetur, adipisicing elit. Exercitationem amet id sunt quasi deleniti similique? Quidem, soluta recusandae! Labore aperiam nemo eaque consectetur! Exercitationem provident consequatur iusto impedit. Quod, cumque?Lorem ipsum dolor sit amet consectetur, adipisicing elit. Exercitationem amet id sunt quasi deleniti similique? Quidem, soluta recusandae! Labore aperiam nemo eaque consectetur! Exercitationem provident consequatur iusto impedit. Quod, cumque? Lorem ipsum dolor sit amet consectetur, adipisicing elit. Exercitationem amet id sunt quasi deleniti similique? Quidem, soluta recusandae! Labore aperiam nemo eaque consectetur! Exercitationem provident consequatur iusto impedit. Quod, cumque? Lorem ipsum dolor sit amet consectetur, adipisicing elit. Exercitationem amet id sunt quasi deleniti similique? Quidem, soluta recusandae! Labore aperiam nemo eaque consectetur! Exercitationem provident consequatur iusto impedit. Quod, cumque?Lorem ipsum dolor sit amet consectetur, adipisicing elit. Exercitationem amet id sunt quasi deleniti similique? Quidem, soluta recusandae! Labore aperiam nemo eaque consectetur! Exercitationem provident consequatur iusto impedit. Quod, cumque? Lorem ipsum dolor sit amet consectetur, adipisicing elit. Exercitationem amet id sunt quasi deleniti similique? Quidem, soluta recusandae! Labore aperiam nemo eaque consectetur! Exercitationem provident consequatur iusto impedit. Quod, cumque? Lorem ipsum dolor sit amet consectetur, adipisicing elit. Exercitationem amet id sunt quasi deleniti similique? Quidem, soluta recusandae! Labore aperiam nemo eaque consectetur! Exercitationem provident consequatur iusto impedit. Quod, cumque?Lorem ipsum dolor sit amet consectetur, adipisicing elit. Exercitationem amet id sunt quasi deleniti similique? Quidem, soluta recusandae! Labore aperiam nemo eaque consectetur! Exercitationem provident consequatur iusto impedit. Quod, cumque? Lorem ipsum dolor sit amet consectetur, adipisicing elit. Exercitationem amet id sunt quasi deleniti similique? Quidem, soluta recusandae! Labore aperiam nemo eaque consectetur! Exercitationem provident consequatur iusto impedit. Quod, cumque? Lorem ipsum dolor sit amet consectetur, adipisicing elit. Exercitationem amet id sunt quasi deleniti similique? Quidem, soluta recusandae! Labore aperiam nemo eaque consectetur! Exercitationem provident consequatur iusto impedit. Quod, cumque?Lorem ipsum dolor sit amet consectetur, adipisicing elit. Exercitationem amet id sunt quasi deleniti similique? Quidem, soluta recusandae! Labore aperiam nemo eaque consectetur! Exercitationem provident consequatur iusto impedit. Quod, cumque? Lorem ipsum dolor sit amet consectetur, adipisicing elit. Exercitationem amet id sunt quasi deleniti similique? Quidem, soluta recusandae! Labore aperiam nemo eaque consectetur! Exercitationem provident consequatur iusto impedit. Quod, cumque? Lorem ipsum dolor sit amet consectetur, adipisicing elit. Exercitationem amet id sunt quasi deleniti similique? Quidem, soluta recusandae! Labore aperiam nemo eaque consectetur! Exercitationem provident consequatur iusto impedit. Quod, cumque?'),
(8, 'Test coourse', 5000, 4, 'lo'),
(9, 'Test course web', 600, 6, 'sdkfjkfnasfafaffa');

-- --------------------------------------------------------

--
-- Table structure for table `course_taking`
--

CREATE TABLE `course_taking` (
  `id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `paid` float NOT NULL,
  `date` datetime DEFAULT CURRENT_TIMESTAMP,
  `end` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course_taking`
--

INSERT INTO `course_taking` (`id`, `course_id`, `student_id`, `teacher_id`, `paid`, `date`, `end`) VALUES
(21, 5, 15, 24, 4000, '2019-12-13 14:54:05', '0000-00-00 00:00:00'),
(24, 5, 16, 13, 10000000, '2019-12-14 07:06:27', '0000-00-00 00:00:00'),
(25, 6, 16, 18, 60000000, '2019-12-14 07:07:41', '0000-00-00 00:00:00'),
(26, 7, 17, 14, 1000, '2019-12-14 11:34:15', '0000-00-00 00:00:00'),
(27, 1, 17, 18, 400, '2019-12-14 11:34:29', '0000-00-00 00:00:00'),
(30, 6, 17, 21, 0, '2019-12-17 08:53:52', '0000-00-00 00:00:00'),
(31, 7, 15, 22, 40000, '2019-12-17 08:57:28', '0000-00-00 00:00:00'),
(32, 5, 15, 22, 20000, '2019-12-17 14:38:40', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `daily_reports`
--

CREATE TABLE `daily_reports` (
  `id` int(10) UNSIGNED NOT NULL,
  `emp_name` varchar(30) NOT NULL,
  `week` int(1) NOT NULL,
  `sdt_name` varchar(30) NOT NULL,
  `course` varchar(50) NOT NULL,
  `topic` varchar(25) NOT NULL,
  `complains` varchar(255) DEFAULT NULL,
  `recommendations` varchar(255) DEFAULT NULL,
  `date` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `daily_reports`
--

INSERT INTO `daily_reports` (`id`, `emp_name`, `week`, `sdt_name`, `course`, `topic`, `complains`, `recommendations`, `date`) VALUES
(89, 'Bin Emmanuel', 3, 'Adeshina', 'Backend Development', 'How to Install XAMPP', 'Testing', 'Testing', '2019-11-27 00:00:00'),
(91, 'Bin Emmanuel', 3, 'Ola', 'Full Stack Web Development', 'PHP Array', NULL, NULL, '2019-12-18 10:12:47'),
(92, 'Bin Emmanuel', 3, 'Uche', 'Full Stack Web Development', 'PHP Array', 'Complains goes here.', NULL, '2019-12-18 10:15:52'),
(93, 'Joseph Bassey', 2, 'Lucy', 'Ms office', 'PowerPoint', NULL, NULL, '2019-12-18 13:05:59'),
(94, 'Tasi Rosel Sona', 3, 'Abraham', 'Coreldraw', 'Tool\'s', NULL, NULL, '2019-12-20 09:16:54');

-- --------------------------------------------------------

--
-- Table structure for table `login_attempts`
--

CREATE TABLE `login_attempts` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `attempt` tinyint(1) NOT NULL,
  `date` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login_attempts`
--

INSERT INTO `login_attempts` (`id`, `user_id`, `attempt`, `date`) VALUES
(22, 1, 3, '2019-12-17 12:28:08'),
(29, 31, 2, '2019-12-21 12:19:55'),
(30, 32, 2, '2019-12-21 14:26:32'),
(31, 33, 1, '2019-12-21 15:27:09'),
(33, 24, 3, '2020-01-08 16:58:36');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `id` int(11) NOT NULL,
  `name` varchar(25) NOT NULL,
  `email` varchar(56) NOT NULL,
  `phone_number` varchar(11) NOT NULL,
  `gender` varchar(6) NOT NULL,
  `date_of_birth` datetime NOT NULL,
  `state` varchar(15) NOT NULL,
  `occupation` varchar(25) NOT NULL,
  `home_address` varchar(155) NOT NULL,
  `next_of_kin` varchar(25) NOT NULL,
  `relationship` varchar(25) NOT NULL,
  `next_of_kins_phone_number` varchar(11) NOT NULL,
  `password` varchar(255) NOT NULL,
  `certificate` int(11) NOT NULL,
  `date` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`id`, `name`, `email`, `phone_number`, `gender`, `date_of_birth`, `state`, `occupation`, `home_address`, `next_of_kin`, `relationship`, `next_of_kins_phone_number`, `password`, `certificate`, `date`) VALUES
(15, 'John Doe', 'doejohn@mail.com', '08123241546', 'Male', '1975-12-31 00:00:00', 'Kogi State', 'Teacher', 'Somewhere, Abuja, Nigeria', 'Jane Doe', 'Uncle', '08123241546', '$2y$10$IZqgjLkcknRm2t5N9iIJJuiGfeYXqc2C.AjCRfbFKF23ESqvCNCcC', 0, '2019-12-13 14:53:50'),
(16, 'ANULIKA UZODI', 'aauzodi@yahoo.com', '08035473861', 'Female', '1984-04-30 00:00:00', 'Enugu', 'Lawyer/ Legal practitione', 'No. 6, Tamale street wuse zone 3, Abuja', 'Nkiru Uzodi', 'Sister', '08105182829', '$2y$10$SsEL5EAArDNbQmVHr16qTe5MF0uyvKNmz6bieYEFAwrj19s66MrgO', 0, '2020-01-09 13:19:23'),
(17, 'AMAKOROMO CALVIN', 'CALVINAMARS@GMAIL.COM', '08162050950', 'Male', '2003-08-07 00:00:00', 'BAYELSA', 'NIL', 'BUAZHIN SHELTERFARM, KUBWA ABUJA', 'AMAKOROMO EBIEME', 'FATHER', '08164283662', '$2y$10$wg9SkhKtA9M/M72Ig6b47uts8UwXLIONaiHrSxRxnsYZcOY3R63XW', 0, '2020-01-09 13:25:24'),
(18, 'YOYINOYE ABAYOMI S.', 'prince4career@gmail.com', '08032097814', 'Male', '1987-06-21 00:00:00', 'Osun', 'Graduate', '421, Otetah close, millionaire Qrt kubwa Abuja, Fct.', 'Taiwo ABAYOMI', 'Wife', '08062931816', '$2y$10$qJdUamcxYKX1rwV9YxBhP.xbL5fc4lsYPhmasUqAR79Dk4zI0hVYa', 0, '2020-01-09 13:32:42'),
(19, 'JOEL BABALOLA', 'babalolajoel@gmail.com', '08169493027', 'Female', '1984-09-27 00:00:00', 'LAGOS', 'CONTRACTOR', '32 CRONDON ESTATE, LUGBE', 'VANESSA BABALOLA', 'Wife', '07064632632', '$2y$10$ZEP6mVajht4nE6YLduGIYel1uPFf7JT/0Nbfl4UhhCvVrom2rFNNu', 0, '2020-01-09 13:38:54'),
(20, 'AKHAGBEME. O. DICKSON', 'Deekhagbeme3@gmail.com', '08101150873', 'Male', '1996-01-08 00:00:00', 'EDO STATE', 'Student', 'A CLOSE Efab Estate, life camp Abuja.', 'JOSEPH', 'Brother', '08158736301', '$2y$10$EQhVMSRpRVjsOWHc91AeQOc8BpimT3u9kMDMj4nFGHRjMI25Lyt1.', 0, '2020-01-09 13:46:59'),
(21, 'AKUJOBI NKEMAKOLAM J.', 'akujobijesse@gmail.com', '08135914059', 'Male', '1993-08-19 00:00:00', 'IMO', 'Student', 'Opposite Anglican church pegi, kuje', 'Omarkhue', 'SON', '08128361711', '$2y$10$9tTVItlFsUQ5MNTFgVWjAuTguQE4akykV1zgFirx35fr8ZG9BKKGi', 0, '2020-01-09 13:55:13'),
(22, 'ADESUNLOYE MICHELLE. S', 'adesunloyemichelle@gmail.com', '08030629130', 'Male', '1987-01-15 00:00:00', 'LAGOS', 'WORKING', 'Kudo Road by Nepa way Kubwa', 'ANITA', 'Sister', '08166708390', '$2y$10$Ruzn2jMELgLH9h7KR9fq/eBysvlDm1xPFq2Yq1hI5RgFQudwyDpsi', 0, '2020-01-09 14:00:29'),
(23, 'OLUWASHINA MOSES LASISI', 'Lasisioluwashina@gmail.com', '08175546854', 'Male', '1998-09-27 00:00:00', 'Oyo', 'Student', 'Block 36, plot 1, dawaki close, kubwa Abuja.', 'ADESHINA LASISI', 'FATHER', '08075177627', '$2y$10$VMuqzlJKZBc9FEieCIO6CugB6HQT8geWLaJtTrtzywVPHEkGfRBHe', 0, '2020-01-09 14:05:13');

-- --------------------------------------------------------

--
-- Table structure for table `time_table`
--

CREATE TABLE `time_table` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `teachers_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `start` datetime NOT NULL,
  `end` datetime NOT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `time_table`
--

INSERT INTO `time_table` (`id`, `student_id`, `teachers_id`, `course_id`, `start`, `end`, `date`) VALUES
(1, 20, 18, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2019-12-01 17:53:37');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) NOT NULL,
  `email` varchar(45) NOT NULL,
  `full_name` varchar(35) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(8) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `profile_pic` varchar(255) NOT NULL,
  `date` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `full_name`, `password`, `role`, `status`, `profile_pic`, `date`) VALUES
(20, 'student@mail.com', 'Student', '$2y$10$T3YuA213INfGIJ7rxL98WONAgWZdDkxI3KJIWOWQBlLtOOLWWQVHK', 'Student', 0, '', '2019-12-01 17:08:35'),
(22, 'binemmanuel@bizmarrow.com.ng', 'Bin Emmanuel', '$2y$10$Gifz/1bwKUdP4WvIbbwmXukQSVWSFubMj5mrR3dHpQuOZ86p5n3I.', 'Trainer', 1, 'bt-contents/images/bizm_28a389d1191f39d95720481b865113a44700cf92.jpeg', '2019-12-18 09:17:46'),
(23, 'info@bizmarrow.com.ng', 'Bizmarrow Info', '$2y$10$stqdfe8vMcO1LcwaOoE1tuKRdDZJS3hzzO147BunYVy1FNB5FrL5q', 'Super Ad', 1, '', '2019-12-18 10:06:44'),
(24, 'josephbassey@bizmarrow.com.ng', 'joseph bassey', '$2y$10$i0umET7oNcOnlcAerRJuoeiyS1RMem7o5hUSz61Tsn53mRsUTWdzm', 'Trainer', 1, 'bt-contents/images/bizm_3cb0e5a94172b56e6da546f9b6c1c25f5ae3063f.jpeg', '2019-12-18 12:32:13'),
(34, 'infotest@bizmarrow.com.ng', 'Infotest', '$2y$10$sXkRx89gg9WbfjPtswMRvuawY.LrbO4jDR6/aRn3BH.o0BKQ7nq.m', 'Trainer', 0, '', '2019-12-22 08:08:04'),
(35, 'adminone@bizmarrow.com.ng', 'Admin', '$2y$10$W5vZIx4xvQeEX7gKZivavO3tWf4eEh4H.QvCug90JuBKVT.5Ktod2', 'Admin', 1, '', '2020-01-09 12:43:46'),
(36, 'admintwo@bizmarrow.com.ng', 'Admin2', '$2y$10$0CGw8gb.hWuSCoSk0qvl7OSkvkp.Fg0yOpxxKsofybOaHup7TllrS', 'Admin', 1, '', '2020-01-09 12:52:07');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `coupon_code`
--
ALTER TABLE `coupon_code`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `course` (`course`),
  ADD KEY `course_2` (`course`);

--
-- Indexes for table `course_taking`
--
ALTER TABLE `course_taking`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `daily_reports`
--
ALTER TABLE `daily_reports`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login_attempts`
--
ALTER TABLE `login_attempts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `time_table`
--
ALTER TABLE `time_table`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `coupon_code`
--
ALTER TABLE `coupon_code`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `course_taking`
--
ALTER TABLE `course_taking`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `daily_reports`
--
ALTER TABLE `daily_reports`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=95;

--
-- AUTO_INCREMENT for table `login_attempts`
--
ALTER TABLE `login_attempts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `time_table`
--
ALTER TABLE `time_table`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
