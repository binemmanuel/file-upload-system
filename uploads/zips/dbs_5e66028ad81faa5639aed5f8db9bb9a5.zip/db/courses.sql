-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jan 14, 2020 at 09:29 AM
-- Server version: 5.7.29
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ictbizma_record`
--

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `id` int(11) NOT NULL,
  `course` varchar(65) NOT NULL,
  `price` int(11) NOT NULL,
  `duration` int(11) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`id`, `course`, `price`, `duration`, `description`) VALUES
(10, 'Computer Appreciation and office management system', 30000, 4, 'Ability to practically work with office packages and internet seamlessly'),
(11, 'Desktop publishing( with corel draw )', 50000, 5, 'Ability to work with office packages seamlessly and Practical knowledge and skills required for the design of images, usable logo’s and banner.'),
(12, 'Desktop Publishing( coreldraw and Photoshop)', 70000, 6, 'Digital IT skills, typing tutorials, printing, internet usage, Microsoft Word, Excel, Power Point, Access, graphic design using Corel Draw and Photoshop'),
(13, 'ADVANCED MICROSOFT OFFICE TRAINING', 60000, 5, 'Digital IT skills, typing overview, Advanced Microsoft word, Excel, Power point, Access'),
(14, 'CERTIFICATE IN HTML, CSS, &amp; BOOTSTRAP', 55000, 3, '•	HTML tags and their applications\r\n•	Control the style and presentation of a web document\r\n•	Build presentable and eye-catching web documents with CSS\r\n•	Build responsive web pages that adapt to different screen sizes with Bootstrap'),
(15, 'DIPLOMA IN WEB DESIGN', 55000, 4, '•	Hypertext markup language (HTML)\r\n•	Cascading Style Sheet (CSS)\r\n•	Domain registration and web hosting\r\n•	Content Management System (CMS)\r\n•	Word press'),
(16, 'CMS  WEB SPECIALIST', 65000, 5, 'Practical knowledge / skills required to register, host and build responsive website using Wordpress and Graphics design using Photoshop'),
(17, 'Foundation of HTML, CSS &amp; JavaScript', 75000, 5, 'practical knowledge/ skills required to control how your Web pages look.  Control the fonts, text, colors, backgrounds, margins, and layout. Coding and designing of beautiful websites.'),
(20, 'Frontend Web specialist (Html, Css, Bootstrap, Javascript and Pho', 125000, 6, 'creativity. Not only can you conceptualize and design a site from start to finish, but you also can create something tangible and impactful'),
(21, 'Frontend Web Design &amp; Development (HTML, CSS, BOOTSTRAP, JAVA', 89000, 6, '•	Ability to build Secured and Quickly Reacting Features and Apps\r\n•	Ability to work with Real-time Programming.\r\n•	Ability to create and design  Responsive  websites'),
(22, 'Advanced web programming/Backend webDevelopment using  (PHP &amp;', 95000, 5, 'practical knowledge /skill required to build dynamic/Database website(building,uploading and finalizing website)'),
(23, 'Complete web specialist  (HTML, CSS, Bootstrap, jQuery JavaScript', 280000, 15, 'practical knowledge /skill required to build dynamic/Database website (building, uploading and finalizing website)\r\n\r\nContents:\r\nHtml\r\nCSS\r\nBootstrap\r\nJQuery\r\nJavascript\r\nPHP\r\nMy SQL\r\nWordpress\r\nphotoshop'),
(24, 'Software Development using Java (MobileApplication)', 85000, 6, 'Practical knowledge and skills required to write error-free-codes and robust applications for Android mobile Devices.\r\n\r\nCourse / Package:\r\nJava ME Android studio'),
(25, 'Fullstack Java programming', 175000, 6, 'Learn how to create ,Implement and deploy web services and web clients using Java Technology components and the Java platform, Companies Utilize the new lightweight Java EE web profile to create next generation web applications through Java EE training , learn the full power of the Java EE platform for Enterprise applications and more.'),
(26, 'Foundations of Java Script and J query', 75000, 4, 'Learn how to design a responsive and robust website\r\nJ query is considered as a write less, do more JavaScript Library\r\nContents\r\nHtml, \r\nCss,\r\n Javascript ,'),
(27, 'Complete React Native training for mobile app development', 220000, 8, 'A multiplatform app development that walks you through the basis of android and  ios app creation. \r\nContents:\r\n Html\r\n CSS\r\n Javascript\r\nES6\r\nReact Native'),
(28, 'Multiplatform Mobile App Development With React Native', 180000, 6, 'Learn how to develop a truly cross-platform, Native iOS and Android App using react native and the Expo SDK.'),
(29, 'ASP.NET Core MVC', 85000, 4, 'This course will cover the fundamentals of what you need to know to start building your first ASP.NET core application with the MVC framework.\r\nASP.NET core is built from the ground up and is a significant redesign of ASP.NET. It provides an optimized development framework for apps or websites that are either run on-premises or deployed o the cloud.'),
(30, 'Foundations of Python Programming', 75000, 5, 'It is a language that is remarkably easy to learn, it can be used as a stepping stone into other programming languages and frameworks. Python allows for a more productive coding environment. \r\nContents\r\nPython'),
(31, 'Full Stack Python ProgrammingHtml, Css , Bootstrap, Javascript, P', 175000, 7, 'Benefits: This also incorporates Django which is a complete and open source web application framework and it is powered by Python. At the end of the training, students will be able to produce application, website etc\r\nContents\r\n\r\nHtml,\r\nCSS,\r\nBootstrap,\r\nJavascript,\r\nPython'),
(32, 'GRAPHICS DESIGN', 48000, 4, 'Practical knowledge and skills required for the design of images, usable logo’s and banners \r\nContents:\r\n	Corel Draw\r\n	Adobe Photoshop'),
(33, 'ADOBE INDESIGN PRICE', 45000, 4, 'Practical knowledge on how to create stunning page layouts, creative print media, e-books and other digital publications faster and more efficiently.\r\nContents\r\n\r\n•	InDesign Training Introduction\r\n•	Text Frame InDesign\r\n•	Introduction to Typography\r\n•	Kerning and Tracking in InDesign  \r\n•	Applying styles in InDesign\r\n•	Working with images in InDesign\r\n•	Document management in InDesign\r\n•	Output'),
(34, 'ADOBE ILLUSTRATOR', 45000, 4, 'it is a vector-based creative program designed for those involved with graphic design. It is used to make everything from business logos to detailed illustration down to animated concepts. Adobe illustrator can also be used to print layout, create stunning websites graphic, and give users complete control over their typography.\r\nContents\r\nAdobe illustrator'),
(35, 'GRAPHIC DESIGN USING ADOBE PACKAGES', 120000, 7, 'Learn how to use Adobe core graphic design software’s and to work with layers. It also gives you an opportunity and edge in web design and UI/U\r\n\r\nContents\r\nAdobe Photoshop\r\nAdobe InDesign\r\nAdobe Illustrator'),
(36, 'VIDEO EDITING', 55000, 4, 'With our hands – on video editing course, you will learn how to perform essential video editing functions and effects to a professional standard. With any of the packages you will be able to:\r\n•	Complete a video editing project from start to finish \r\n•	Create titles\r\n•	Edit footage and audio together \r\n•	Work with audio to adjust volume levels at specific times \r\n•	Understand the basics of color correction and color grading \r\n•	Understand various resolutions and editing workflows\r\n•	Learn how to export video'),
(37, 'ADOBE AFTER EFFECTS', 60000, 4, 'Practical knowledge on keying, tracking, composition and animation\r\nContents\r\nAdobe after effects\r\n•	Post production / video editing \r\n•	Visual effects.\r\n•	Video manipulation.\r\n•	Text Animation.\r\n•	2D character Animation.\r\n•	Explainer Videos.'),
(38, '3-D MODELING AND ANIMATION USING AUTODESK MAYA', 85000, 4, 'Ability to create realistic 3D models, 3D applications, animated movies, TV serials, technical-non-technical commercials, 3D video games, visual effects and many other effects. \r\nContents\r\n•	3D Modeling\r\n•	Animation'),
(39, 'Multimedia specialist', 125000, 7, 'Be a sort after multimedia pro. Learn to use Photoshop, After Effects and Adobe Premier Pro packages to create eye-catching videos\r\ncontents\r\n•	Photoshop \r\n•	After Effect \r\n•	Premier Pro'),
(40, 'Introduction to Ethical hacking', 150000, 6, '•	Benefits: Our course is completely in Tamil.Very easy to understand.\r\n•	You will learn how to gather information about the target\r\n•	You will learn how to scan the entire network with different tools and techniques\r\n•	You will learn how to port forward without using static IP address\r\n•	You will also learn about how to find vulnerabilities about the given target in different ways\r\n•	You will learn how to create basic as well as advanced malware creation\r\n•	You will learn about a famous tool” Metasploit Framework”\r\n•	You will learn about Advanced web application techniques and attacks on real websites'),
(41, 'GIS &amp; ARC GIS', 68000, 4, 'Using GIS allow people to see the world in a different way by mapping the position and quantity of things, mapping the density of people and objects and mapping any changes that occur. GIS also allows us to find out what is happening inside a specific area or nearby to a specific area'),
(42, 'Prota Structure Training', 75000, 6, 'An innovative software solution for structural engineers to model, load, analyze and design reinforced concrete, steel and composite structures. At the end of the course students shall be able to;\r\n\r\nAcquaint themselves with the tools and workspace.\r\nModel, load, analyze and design simple building structures.\r\nDesign a 3 storey building project using this software.\r\nExport detail drawings to AutoCAD workspace'),
(43, 'SAP2000 Training', 75000, 6, 'A general purpose civil engineering software ideal for the analysis and design of any structure. It has been used to design some of the world’s most prominent structures in the US. At the end of the course students shall be able to;\r\n\r\nAcquaint themselves with the tools and workspace.\r\nModel, load analyze and design simple structures\r\nDesign a 3 storey building project using this software'),
(44, 'Tekla Structural Designer Training', 75000, 6, 'A revolutionary software that gives engineers the power to analyze and design buildings. At the end of the course students shall be able to;\r\n\r\nAcquaint themselves with the tools and workspace.\r\nModel, load analyze and design simple structures\r\nDesign a 3 storey building project using this software'),
(45, 'Sage 50 Accounting', 65000, 2, 'This is perfectly designed to give you the knowledge and skills necessary to set up and use Peachtree Accounting Software efficiently with the advanced features. It is designed for those trying to expand their knowledge in accounting or those looking for an entrance point to attain a position in the field.'),
(46, 'Quick Book Accounting', 65000, 2, 'Upon course completion, students will be able to identify QuickBook Accounting features; Perform New Company Set-up; Understand basic accounting functions; Perform General Ledger functions; Use standard Accounts Payable features; Understand basic Inventory functions; Use standard Account Receivable functions; and use realistic activities to understand each objective. It is primarily for all organization and those with little knowledge of QuickBook who would like to understand more about the day-to-day inputting of their account on computer.'),
(47, 'Microsoft Project.', 39000, 2, 'Microsoft project gives you robust project management tools with the right blend of usability, power, and flexibility so you can manage project more efficiently and effectively. Microsoft project also lets you easily plan project, effectively manage resource and collaborate with others.'),
(48, 'Microsoft Project And  Project Management Training', 65000, 4, 'Benefits:  Microsoft project gives you robust project management tools with the right blend of usability, power, and flexibility so you can manage project more efficiently and effectively. Microsoft project also lets you easily plan project, effectively manage resource and collaborate with others. This training also takes the students deep into project management'),
(49, 'Project Management Training Leading To Pmp.', 35000, 2, 'Benefits:  Microsoft project gives you robust project management tools with the right blend of usability, power, and flexibility so you can manage project more efficiently and effectively. Microsoft project also lets you easily plan project, effectively manage resource and collaborate with others. This training also takes the students deep into project management'),
(50, 'Data Analysis using EXCEL', 65000, 4, 'Learn to apply the important concepts and techniques of data analysis using Excel. This training helps you to harness the Power of Excel to Discover What Your Numbers are Hiding'),
(51, 'Data Analysis using STATA', 82000, 4, 'Master STATA for data management, graphs and data analysis with TIPS for the best workflow. This course provides all you need to know to start using Stata to analyze your data'),
(52, 'Data Analysis using SPSS', 85000, 4, 'SPSS (The Statistical Package for the Social Sciences) software has been developed by IBM and it is widely used to analyze data and make predictions based on specific collections of data\r\nA complete step by step course to master IBM SPSS Statistics for doing advanced Research, Statistics &amp; Data Analysis-- Increase Your Data Analytic Skills – Highly Valued And Sought After By Employers'),
(53, 'Sales and Marketing training', 40000, 4, 'This course will explore different sales and marketing techniques, and will provide learners with more tools and ideas to maximise individual and team sales. This will include templates for writing sales letters, buying facilitation, cold-calling techniques and other techniques proven by research to create profits. Also discussed will be advertising techniques, and market development programs designed to optimize revenue in new markets.'),
(54, 'Logistics and Supply Chain Management Training', 65000, 2, 'The importance of careful management of logistics and  supply chain is now most critical. Companies should recognize that proper management of the supply chain will contribute immensely to reduced cost and, in effect, increased profit. \r\nThis course addresses supply chain issues thoroughly. It treats the influence of technology, modernized transportation and the increasing complexity of modern logistics. It presents opportunities to improve productivity, inventory and distribution, as well as service levels through the active coordination and relationship of Suppliers, Producers and Customers.'),
(55, 'Strategic Procurement Management training', 60000, 2, 'Strategic procurement management training is key for many projects, because procured goods and services form the highest percentages of expenditure and so it is important to achieve value for money through careful appraisal and management. \r\nThis course aims to equip you with the capacity to develop management and strategic skills in procurement in order to increase Value for Money. It will enable you to assess the meanings and outcomes of the stages in the development of an effective procurement strategy. It will develop your skills on how the process should be undertaken.'),
(56, 'Foundations of Digital marketing and graphics design', 150000, 6, '•	Introduction to digital marketing\r\n•	Understanding the secret behind digital marketing and digital marketing strategy\r\n•	Search engine optimization \r\n•	SEO Copywriting—How to write articles that attract paying customers\r\n•	Keyword research and Analysis \r\n•	Competition research and Analysis\r\n•	Social media marketing \r\n•	YouTube marketing\r\n•	Introduction to Conversion Rate Optimization\r\n•	Content marketing\r\n•	Link building\r\n•	Online advertising\r\n•	Email marketing\r\n•	Google my business\r\n•	Graphics design for digital campaign and advertisement ( photoshop and corel draw)'),
(57, 'Complete Digital marketing and CMS website designing Training', 170000, 6, '•	Introduction to digital marketing\r\n•	Understanding the secret behind digital marketing and digital marketing strategy\r\n•	Search engine optimization \r\n•	SEO Copywriting—How to write articles that attract paying customers\r\n•	Keyword research and Analysis \r\n•	Competition research and Analysis\r\n•	Social media marketing \r\n•	YouTube marketing\r\n•	Introduction to Conversion Rate Optimization\r\n•	Content marketing\r\n•	Link building\r\n•	Online advertising\r\n•	Email marketing\r\n•	Google my business\r\n•	Website design and application of digital marketing using  WordPress\r\na)	How to run SEO –on a life website to attract targeted paying cutomers\r\nb)	Application of Content Marketing and SEO copywriting on a  website\r\nc)	Application of Link building on a  website\r\nd)	Integration of social media site with a website'),
(58, 'Advanced Digital Marketing', 220000, 8, '•	Introduction to digital marketing\r\n•	Understanding the secret behind digital marketing and digital marketing strategy\r\n•	Conversion rate optimization(CRO)\r\n•	Link building \r\n•	Keyword research analysis\r\n•	Competition research  analysis\r\n•	Search engine optimization (SEO)\r\n•	SEO Copywriting—How to write articles that attract customers\r\n•	Content marketing\r\n•	Email marketing\r\n•	YouTube marketing\r\n•	Social media  marketing(Facebook, Twitter, Instagram)\r\n•	Web analytics using Google Analytics\r\n•	Google my business\r\n•	Branding and online reputation \r\n•	Remarketing \r\n•	Blogging for business \r\n•	Influencer marketing\r\n•	Website design and application of digital marketing using  WordPress\r\n•	Graphics design for digital campaign ( photoshop and Coreldraw)'),
(59, 'Blogging Master Class', 85000, 5, '•	Introduction to blogging as a business\r\n•	Domain Registration and webhosting\r\n•	Website design using wordpress\r\n•	Understanding a niche market and marketing\r\n•	Niche keyword research and analysis\r\n•	Competition research\r\n•	Search engine optimization (SEO)\r\n•	Secrete of Link Building\r\n•	Social media marketing\r\n•	Video marketing using YouTube\r\n•	How to create a business around your blog \r\n•	Blogging cash machine—How to make money using your blog'),
(60, 'Online Reputation Management', 65000, 4, 'Learn how to develop, manage and protect an organization’s online reputation throughout the internet\r\nOnline reputation management means taking control of what people who search for you or your business see on the internet --search engines, social media websites and other blog websites. Its techniques and strategies ensure that people find the right materials when they look for you online\r\nThis online reputation management course covers the following\r\n•	How to Plan and execute online PR campaigns from start to finish \r\n•	Key concept --Reputation Marketing vs. Management, Good Reputation, No Reputation, Bad Reputation\r\n•	Getting your Brand SEO right------How do you want to be seen on Google, when a search is done on your name? Making Google to say what you want the public to hear\r\n•	Brand Keyword, competition research and analysis ---Everybody has a name, when the name is mentioned , they answer, Keywords are like names, which ones does your brand come up when they are mentioned\r\n•	How to Identify online opportunities and threats'),
(61, 'Social Media Marketing  fundamentals', 45000, 3, 'Learn how to utilize the power of social media to market your business in this detailed course that covers setup, ongoing management, and also countless tools and tactics.\r\n\r\n•	 Introduction to Social Media Marketing\r\n•	 Introduction to Facebook\r\n•	 Facebook Advertising\r\n•	 Introduction to LinkedIn\r\n•	 Introduction to YouTube\r\n•	 Instagram &amp; Twitter\r\n•	 Introduction to Google my business &amp; Blogging\r\n•	 Measurement &amp; Optimization'),
(62, 'Social Media Marketing Specialist', 68000, 5, 'This course is a complete guide to start and run a successful social media campaign for any business. It covers everything from how you should approach social media, to setting up your presence on the relevant platforms, and also how to manage your accounts either in-house or outsourced. It goes into even more depth by suggesting the adequate content format and structure for the main platforms and also comes with a comprehensive list of tested resources and practices to catalyze your efforts. Simply said, this course puts you at the top of your game when it comes to social media marketing.\r\n\r\nYou will learn about the challenges involved in implementing an effective social media strategy for your business or clients business , especially when using paid advertising options. And how to schedule, manage and report on your campaigns.\r\nSocial media marketing is a show biz, you can’t get it right without the knowledge of graphics. So this training includes graphics design for social media'),
(63, 'Digital Marketing Fundamentals', 65000, 4, '•	Introduction to digital marketing\r\n•	Understanding the secret behind digital marketing and digital marketing strategy\r\n•	Social media marketing\r\n•	Content marketing\r\n•	Link building\r\n•	Online advertising\r\n•	Email marketing\r\n•	Search engine optimization\r\n•	Keyword research and analysis \r\n•	Google my business');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `course` (`course`),
  ADD KEY `course_2` (`course`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=64;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
